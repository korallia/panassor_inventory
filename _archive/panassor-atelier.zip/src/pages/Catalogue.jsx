// Catalogue (CMS, plus tard). Pour l'instant : créer une pièce ou un outil
// dans les données d'exemple pour voir comment il s'intègre au registre.
// Rien n'est envoyé à Square ni au site.
import { useState } from "react";
import { useNavigate } from "react-router-dom";

import { useInventory } from "../store.jsx";
import { SampleNote } from "../components/ui.jsx";

const TYPES = [
  { id: "piece", label: "Pièce", ready: true },
  { id: "outil", label: "Outil au choix", ready: true },
  { id: "ensemble", label: "Ensemble", ready: false },
  { id: "paquet", label: "Paquet", ready: false },
  { id: "kit", label: "Kit", ready: false },
];

function slugify(text) {
  return text
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export default function Catalogue() {
  const { collections, productsById, dispatch } = useInventory();
  const navigate = useNavigate();
  const [type, setType] = useState("outil");
  const [form, setForm] = useState({
    nameFr: "",
    nameEn: "",
    descFr: "",
    descEn: "",
    price: "",
    stock: "0",
    min: "4",
    collectionId: collections[0]?.id,
  });
  const set = (key) => (event) => setForm((f) => ({ ...f, [key]: event.target.value }));
  const typeReady = TYPES.find((t) => t.id === type)?.ready;
  const canSave = typeReady && form.nameFr.trim();

  function save(event) {
    event.preventDefault();
    if (!canSave) return;
    let id = slugify(form.nameFr) || "produit";
    while (productsById[id]) id += "-2";
    dispatch({
      type: "addProduct",
      product: {
        id,
        collectionId: form.collectionId,
        name: form.nameFr.trim(),
        type,
        stock: Math.max(0, parseInt(form.stock, 10) || 0),
        min: Math.max(0, parseInt(form.min, 10) || 0),
      },
    });
    navigate(`/produits/${id}`);
  }

  return (
    <form onSubmit={save} className="flex flex-col gap-6">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          <div className="eyebrow">Catalogue · {collections.find((c) => c.id === form.collectionId)?.name}</div>
          <h1 className="sc m-0 mt-1.5 text-[40px] leading-none text-cream sm:text-[48px]">Nouveau produit</h1>
        </div>
        <div className="flex flex-wrap gap-3">
          <button type="submit" className="btn-primary" disabled={!canSave}>
            Ajouter à l'inventaire
          </button>
          <button type="button" className="btn-ghost" disabled title="Pas branché : données d'exemple">
            Publier et envoyer à Square
          </button>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="flex flex-col gap-5 border border-line bg-panel p-6">
          <div>
            <span className="lbl mb-1.5 block">Type de produit</span>
            <div role="radiogroup" aria-label="Type de produit" className="flex flex-wrap">
              {TYPES.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  role="radio"
                  aria-checked={type === t.id}
                  onClick={() => setType(t.id)}
                  className={`h-11 cursor-pointer border px-4 text-[17px] ${
                    type === t.id ? "border-gold bg-gold/15 text-cream" : "border-line bg-transparent text-muted2"
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
            {!typeReady && (
              <div className="mt-2 text-[16px] text-warn">
                Ce type demande de choisir ses composants : prévu pour la version reliée à la base.
              </div>
            )}
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Nom (FR)">
              <input className="field" value={form.nameFr} onChange={set("nameFr")} placeholder="Ex. Tourne-serrure" required />
            </Field>
            <Field label="Nom (EN)">
              <input className="field" value={form.nameEn} onChange={set("nameEn")} placeholder="Ex. Lock Turner" />
            </Field>
            <Field label="Description courte (FR)">
              <textarea className="field h-24! py-2" value={form.descFr} onChange={set("descFr")} />
            </Field>
            <Field label="Description courte (EN)">
              <textarea className="field h-24! py-2" value={form.descEn} onChange={set("descEn")} />
            </Field>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Prix ($)">
              <input className="field" inputMode="decimal" value={form.price} onChange={set("price")} placeholder="40,00" />
            </Field>
            <Field label="Stock de départ">
              <input className="field" inputMode="numeric" value={form.stock} onChange={set("stock")} />
            </Field>
            <Field label="Minimum libre">
              <input className="field" inputMode="numeric" value={form.min} onChange={set("min")} />
            </Field>
            <Field label="Collection">
              <select className="field bg-panel2!" value={form.collectionId} onChange={set("collectionId")}>
                {collections.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </Field>
          </div>

          <div>
            <span className="lbl mb-1.5 block">Photos</span>
            <div className="flex gap-3">
              <div className="flex h-24 w-24 items-center justify-center border border-dashed border-line text-[15px] text-faint">
                + Ajouter
              </div>
            </div>
          </div>
        </div>

        <aside className="flex flex-col gap-4">
          <div className="flex flex-col gap-2.5 border border-line bg-panel p-5">
            <div className="lbl">Publication</div>
            <label className="flex items-center gap-2.5 text-[17px] text-muted">
              <input type="checkbox" defaultChecked={type === "outil"} key={type} className="accent-[#c89b3c]" />
              Proposé comme outil au choix dans les kits
            </label>
            <label className="flex items-center gap-2.5 text-[17px] text-muted">
              <input type="checkbox" defaultChecked className="accent-[#c89b3c]" />
              Synchroniser avec Square
            </label>
            <label className="flex items-center gap-2.5 text-[17px] text-muted">
              <input type="checkbox" className="accent-[#c89b3c]" />
              Visible sur le site
            </label>
          </div>
          <div className="text-[15px] text-faint">
            Dans cette version, « Ajouter à l'inventaire » crée le produit dans les données d'exemple seulement, pour voir sa fiche
            et sa place dans le registre.
          </div>
          <SampleNote />
        </aside>
      </div>
    </form>
  );
}

function Field({ label, children }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="lbl">{label}</span>
      {children}
    </label>
  );
}
