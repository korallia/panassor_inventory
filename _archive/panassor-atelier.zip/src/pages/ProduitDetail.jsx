// Fiche produit : visuel d'abord (1 case = 1 unité), les chiffres ensuite.
//   1C     outil / pièce
//   1D(1)  paquet (aiguilles de suture)
//   1D(2)  ensemble (ex. Crochet + tourne-serrure)
import { Link, useParams } from "react-router-dom";

import { useInventory } from "../store.jsx";
import {
  ensembleState,
  leatherTotal,
  packMissingByType,
  packOrphans,
  productState,
} from "../lib/inventory.js";
import {
  Legend,
  PageHeader,
  SampleNote,
  SlotGroup,
  Slots,
  StatTile,
  StatusBanner,
  Stepper,
  typeLabel,
} from "../components/ui.jsx";

export default function ProduitDetail() {
  const { id } = useParams();
  const { productsById, collections } = useInventory();
  const product = productsById[id];

  if (!product) {
    return (
      <div className="flex flex-col gap-4">
        <Link to="/inventaire">← Inventaire</Link>
        <p className="text-[19px]">Produit introuvable.</p>
      </div>
    );
  }

  const collection = collections.find((c) => c.id === product.collectionId);
  const props = { product, collectionName: collection?.name ?? "" };

  if (product.type === "ensemble") return <EnsembleDetail {...props} />;
  if (product.type === "paquet") return <PackDetail {...props} />;
  return <PieceDetail {...props} />;
}

/** Kits qui utilisent ce produit, pour dire « réservés pour 8 kits du chirurgien ». */
function useKitsUsing(productId) {
  const { kits } = useInventory();
  return kits.filter((kit) => kit.components.some((c) => c.productId === productId));
}

function reservedLabel(count, unit, kitsUsing) {
  const names = kitsUsing.map((kit) => `${leatherTotal(kit)} ${kit.name.toLowerCase().replace(/^kit /, "kits ")}`);
  return `${count} ${unit} · pour ${names.join(" + ") || "aucun kit"}`;
}

// ---------------------------------------------------------------- 1C
function PieceDetail({ product, collectionName }) {
  const { reserved, products, dispatch } = useInventory();
  const state = productState(product, reserved);
  const kitsUsing = useKitsUsing(product.id);
  const ensembles = products.filter((p) => p.type === "ensemble" && p.components.some((c) => c.productId === product.id));
  const low = state.status === "low";
  const singular = product.name.toLowerCase();

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        back={{ to: "/inventaire", label: "Inventaire" }}
        eyebrow={`${collectionName} · ${typeLabel(product, kitsUsing.length > 0).toLowerCase()}`}
        title={product.name}
      >
        <StatusBanner low={low} missing={state.missingForMin} missingLabel="à fabriquer" />
      </PageHeader>

      <div
        className="flex flex-col gap-5 border border-line px-6 py-7 sm:px-9"
        style={{ background: "linear-gradient(180deg,#140d07 0%,#0b0704 100%)" }}
      >
        <div className="flex flex-wrap items-end gap-7">
          {state.reserved > 0 && (
            <SlotGroup label={reservedLabel(state.reserved, "réservés", kitsUsing)} bracketColor="#9fc7a4">
              <Slots kind="reserved" count={state.reserved} title="Réservé pour un kit" />
            </SlotGroup>
          )}
          <SlotGroup label={`${state.free} libres · minimum ${state.min}`}>
            <Slots kind="free" count={state.free} title="Libre" />
            <Slots kind="missing" count={state.missingForMin} title="Manque pour le minimum" />
            {state.free === 0 && state.missingForMin === 0 && <span className="text-[17px] text-faint">Aucune</span>}
          </SlotGroup>
        </div>
        <div className="flex flex-wrap gap-x-7 gap-y-2 text-[16px] text-muted2">
          <span className="text-parch">Chaque case = 1 {singular}.</span>
          <Legend kind="reserved">Réservé pour un kit</Legend>
          <Legend kind="free">Libre, vendable seul</Legend>
          <Legend kind="missing">Manque pour atteindre le minimum</Legend>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="En stock" value={state.stock} />
        <StatTile label="Réservés" value={state.reserved} />
        <StatTile label="Libres" value={state.free} alert={low} />
        <StatTile label="Minimum libre" value={state.min} />
      </div>

      <div className="flex flex-wrap items-center gap-x-8 gap-y-4 border border-line bg-panel px-6 py-5">
        <div className="lbl">Tester</div>
        <label className="flex items-center gap-3 text-[17px] text-muted">
          Stock total
          <Stepper
            label={`Stock ${product.name}`}
            value={product.stock}
            onChange={(value) => dispatch({ type: "setStock", productId: product.id, value })}
          />
        </label>
        <label className="flex items-center gap-3 text-[17px] text-muted">
          Minimum libre
          <Stepper
            label={`Minimum ${product.name}`}
            value={product.min ?? 0}
            onChange={(value) => dispatch({ type: "setMin", productId: product.id, value })}
          />
        </label>
      </div>

      {ensembles.length > 0 && (
        <div className="text-[17px] text-muted2">
          Aussi utilisé dans :{" "}
          {ensembles.map((ensemble, index) => (
            <span key={ensemble.id}>
              {index > 0 && ", "}
              <Link to={`/produits/${ensemble.id}`}>{ensemble.name}</Link>
            </span>
          ))}{" "}
          (sur le stock libre seulement).
        </div>
      )}
      <SampleNote />
    </div>
  );
}

// ---------------------------------------------------------------- 1D(1)
function PackDetail({ product, collectionName }) {
  const { reserved, dispatch } = useInventory();
  const state = productState(product, reserved);
  const kitsUsing = useKitsUsing(product.id);
  const orphans = packOrphans(product);
  const missingByType = packMissingByType(product, reserved);
  const low = state.status === "low";
  const plural = (n) => (n === 1 ? "paquet" : "paquets");
  const composition = product.packTypes.map((type) => `1 ${type.name.toLowerCase().replace(/s$/, "")}`).join(" + ");

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        back={{ to: "/inventaire", label: "Inventaire" }}
        eyebrow={`${collectionName} · paquet de ${product.packTypes.length}`}
        title={product.name}
      >
        <StatusBanner low={low} missing={state.missingForMin} missingLabel={`${plural(state.missingForMin)} à faire`} />
      </PageHeader>

      <div
        className="flex flex-col gap-4 border border-line px-6 py-6 sm:px-8"
        style={{ background: "linear-gradient(180deg,#140d07 0%,#0b0704 100%)" }}
      >
        <div className="flex flex-wrap gap-7">
          {state.reserved > 0 && (
            <SlotGroup
              label={reservedLabel(state.reserved, `${plural(state.reserved)} réservés`, kitsUsing)}
              bracketColor="#9fc7a4"
              labelColor="#9fc7a4"
            >
              <Slots kind="reserved" count={state.reserved} />
            </SlotGroup>
          )}
          <SlotGroup label={`${state.free} ${plural(state.free)} ${state.free === 1 ? "libre" : "libres"} · minimum ${state.min}`}>
            <Slots kind="free" count={state.free} />
            <Slots kind="missing" count={state.missingForMin} />
          </SlotGroup>
        </div>
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-[16px] text-muted2">
          <span className="text-parch">Chaque case = 1 paquet de {product.packTypes.length}.</span>
          <Legend kind="reserved">Réservé pour un kit</Legend>
          <Legend kind="free">Libre</Legend>
          <Legend kind="missing">Manque pour le minimum</Legend>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile label="En stock" value={state.stock} unit={plural(state.stock)} />
        <StatTile label="Réservés" value={state.reserved} unit={plural(state.reserved)} />
        <StatTile label="Libres" value={state.free} unit={plural(state.free)} alert={low} />
        <StatTile label="Minimum libre" value={state.min} unit={plural(state.min)} />
      </div>

      <section className="flex max-w-[1150px] flex-col gap-2 border border-line bg-panel px-6 py-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="sc text-[16px] tracking-[.16em] text-gold">Pièces en stock</div>
          <div className="flex flex-wrap gap-x-5 gap-y-2 text-[16px] text-muted">
            <Legend kind="reserved" layer={1}>
              Réservé pour les kits · jamais compté
            </Legend>
            <Legend kind="free" layer={2}>
              Paquets libres
            </Legend>
            <Legend kind="orphan">Orpheline</Legend>
            <Legend kind="missing">Manque</Legend>
          </div>
        </div>

        {product.packTypes.map((type, index) => {
          const orphanCount = orphans[index].orphans;
          const missing = missingByType[index].missing;
          return (
            <div key={type.id} className="flex flex-wrap items-center gap-4 border-t border-line/35 py-2.5">
              <div className="w-[150px]">
                <div className="text-[21px] text-cream">{type.name}</div>
                <div className="lbl mt-1">{type.stock} en stock</div>
                <div className="mt-2">
                  <Stepper
                    small
                    label={`Stock ${type.name}`}
                    value={type.stock}
                    onChange={(value) => dispatch({ type: "setPackStock", productId: product.id, typeId: type.id, value })}
                  />
                </div>
              </div>
              <div className="order-last flex w-full min-w-0 flex-wrap items-center gap-1 sm:order-none sm:w-auto sm:flex-1">
                <Slots kind="reserved" count={state.reserved} size="sm" />
                {state.reserved > 0 && <span className="w-2.5" />}
                <Slots kind="free" count={state.free} size="sm" />
                <Slots kind="orphan" count={orphanCount} size="sm" title="Orpheline" />
                <Slots kind="missing" count={missing} size="sm" title="Manque" />
              </div>
              <div className="ml-auto w-[130px] text-right">
                {missing > 0 ? (
                  <>
                    <div className="lbl" style={{ color: "#e8876f" }}>
                      Manque
                    </div>
                    <div className="text-[30px] leading-none text-alert-soft">{missing}</div>
                  </>
                ) : (
                  <>
                    <div className="lbl" style={{ color: "#e7c97b" }}>
                      Libres
                    </div>
                    <div className="text-[30px] leading-none text-cream">
                      {state.free}
                      {orphanCount > 0 && <span className="ml-1 text-[16px] text-faint">+ {orphanCount} orph.</span>}
                    </div>
                  </>
                )}
              </div>
            </div>
          );
        })}

        <div className="mb-1.5 text-[15px] text-faint">
          Chaque case = 1 pièce. Un paquet = {composition}.
          {orphans.some((o) => o.orphans > 0) && (
            <>
              {" "}
              Les pièces orphelines ne comptent pas dans le stock tant qu'il leur manque leur paire.
            </>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-baseline gap-2.5 border border-gold bg-panel2 px-4 py-2.5">
            <span className="text-[30px] leading-none text-cream">{state.stock}</span>
            <span className="text-[17px] text-muted">
              {plural(state.stock)} · {composition}
            </span>
          </div>
          {orphans
            .filter((o) => o.orphans > 0)
            .map((o) => (
              <div key={o.id} className="flex items-baseline gap-2.5 border border-[#8f8577] bg-[#1c1915] px-4 py-2.5">
                <span className="text-[30px] leading-none text-muted2">{o.orphans}</span>
                <span className="text-[17px] text-faint">{o.name.toLowerCase()} orphelines · hors stock</span>
              </div>
            ))}
        </div>
      </section>
      <SampleNote />
    </div>
  );
}

// ---------------------------------------------------------------- 1D(2)
function EnsembleDetail({ product, collectionName }) {
  const { productsById, reserved, dispatch } = useInventory();
  const state = ensembleState(product, productsById, reserved);
  const low = state.possible < state.objective;
  const short = state.objective - state.possible;
  const missingParts = state.parts.filter((part) => part.missing > 0);

  return (
    <div className="flex flex-col gap-5">
      <PageHeader back={{ to: "/inventaire", label: "Inventaire" }} eyebrow={`${collectionName} · ensemble`} title={product.name}>
        <StatusBanner low={low} lowLabel="Sous l'objectif" missing={short} missingLabel={short === 1 ? "ensemble" : "ensembles"} />
      </PageHeader>

      <div
        className="flex flex-col gap-3.5 border border-line px-6 py-6 sm:px-8"
        style={{ background: "linear-gradient(180deg,#140d07 0%,#0b0704 100%)" }}
      >
        <SlotGroup label={`${state.possible} ensembles possibles · objectif ${state.objective}`}>
          <Slots kind="free" count={state.possible} />
          <Slots kind="missing" count={Math.max(0, short)} />
        </SlotGroup>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[16px] text-muted2">
          <span className="text-parch">Chaque case = 1 ensemble.</span>
          <Legend kind="free">Possible avec le stock libre</Legend>
          <Legend kind="missing">Manque pour l'objectif</Legend>
          <span>Rien n'est réservé</span>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatTile label="Possibles" value={state.possible} unit="ensembles" alert={low} />
        <StatTile label="Objectif" value={state.objective} unit="ensembles" />
        <div className={`border px-5 py-4 ${missingParts.length ? "border-alert-line bg-alert-bg" : "border-line bg-panel2"}`}>
          <div className="lbl" style={missingParts.length ? { color: "#d7b5a8" } : undefined}>
            Manque
          </div>
          {missingParts.length === 0 ? (
            <div className="mt-2 text-[40px] leading-[1.1] text-cream">—</div>
          ) : (
            missingParts.map((part) => (
              <div key={part.product.id} className="mt-2 text-[40px] leading-[1.1] text-alert-soft">
                {part.missing} <span className="text-[20px] text-alert-muted">{part.product.name.toLowerCase()}</span>
              </div>
            ))
          )}
        </div>
      </div>

      <section className="flex flex-col gap-2 border border-line bg-panel px-6 py-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="sc text-[16px] tracking-[.16em] text-gold">Pièces de l'ensemble</div>
          <div className="flex flex-wrap gap-x-5 gap-y-2 text-[16px] text-muted">
            <Legend kind="reserved" layer={1}>
              Réservé pour les kits · jamais compté
            </Legend>
            <Legend kind="free" layer={2}>
              Pour les ensembles
            </Legend>
            <Legend kind="solo" layer={3}>
              Vendable seul
            </Legend>
            <Legend kind="missing">Manque</Legend>
          </div>
        </div>

        {state.parts.map((part) => (
          <div key={part.product.id} className="flex flex-wrap items-center gap-4 border-t border-line/35 py-2.5">
            <div className="w-[170px]">
              <Link to={`/produits/${part.product.id}`} className="text-[21px] text-cream!">
                {part.product.name}
              </Link>
              <div className="lbl mt-1">
                {part.stock} en stock{part.qty > 1 ? ` · ${part.qty} par ensemble` : ""}
              </div>
            </div>
            <div className="order-last flex w-full min-w-0 flex-wrap items-center gap-1 sm:order-none sm:w-auto sm:flex-1">
              <Slots kind="reserved" count={part.reserved} size="sm" />
              {part.reserved > 0 && <span className="w-2.5" />}
              <Slots kind="free" count={part.forEnsembles} size="sm" />
              <Slots kind="solo" count={part.soloOnly} size="sm" />
              <Slots kind="missing" count={part.missing} size="sm" />
            </div>
            <div className="ml-auto w-[120px] text-right">
              <div className="lbl" style={{ color: "#e7c97b" }}>
                Libres
              </div>
              <div className={`text-[30px] leading-none ${part.missing > 0 ? "text-alert-soft" : "text-cream"}`}>{part.free}</div>
            </div>
          </div>
        ))}
        <div className="text-[15px] text-faint">
          Chaque case = 1 pièce. Seules les pièces libres (après les kits) servent au calcul des ensembles.
        </div>
      </section>

      <div className="flex flex-wrap items-center gap-x-8 gap-y-4 border border-line bg-panel px-6 py-5">
        <div className="lbl">Tester</div>
        <label className="flex items-center gap-3 text-[17px] text-muted">
          Objectif
          <Stepper
            label={`Objectif ${product.name}`}
            value={product.objective ?? 0}
            onChange={(value) => dispatch({ type: "setObjective", productId: product.id, value })}
          />
        </label>
        {state.parts.map((part) => (
          <label key={part.product.id} className="flex items-center gap-3 text-[17px] text-muted">
            {part.product.name}
            <Stepper
              label={`Stock ${part.product.name}`}
              value={part.product.stock}
              onChange={(value) => dispatch({ type: "setStock", productId: part.product.id, value })}
            />
          </label>
        ))}
      </div>
      <SampleNote />
    </div>
  );
}
