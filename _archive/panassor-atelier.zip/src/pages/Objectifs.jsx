// Objectifs : quantité, date, raison. « 8 kits complets + 10 de chaque
// outil » devient un objectif par pièce : base + 8 × pièces par kit.
import { useState } from "react";

import { useInventory } from "../store.jsx";
import { leatherTotal, objectiveNeeds } from "../lib/inventory.js";
import { SampleNote } from "../components/ui.jsx";

function formatDate(value) {
  if (!value) return "[date]";
  const date = new Date(`${value}T12:00:00`);
  return date.toLocaleDateString("fr-CA", { day: "numeric", month: "long", year: "numeric" });
}

function progressOf(objective, kits, productsById) {
  const kit = kits.find((k) => k.id === objective.kitId);
  const needs = objectiveNeeds(objective, kit, productsById);
  const leatherTarget = objective.kitCount;
  const leatherHave = kit ? Math.min(leatherTotal(kit), leatherTarget) : 0;
  const target = needs.reduce((sum, n) => sum + n.target, 0) + leatherTarget;
  const have = needs.reduce((sum, n) => sum + Math.min(n.stock, n.target), 0) + leatherHave;
  return { kit, needs, target, have, missing: target - have, leatherHave, leatherTarget };
}

export default function Objectifs() {
  const { objectives, kits, productsById, dispatch } = useInventory();
  const [selectedId, setSelectedId] = useState(objectives[0]?.id);
  const current = objectives.find((o) => o.id === selectedId) ?? objectives[0];

  return (
    <div className="grid gap-7 xl:grid-cols-[minmax(0,1fr)_360px]">
      <div className="flex min-w-0 flex-col gap-5">
        {current ? <ObjectiveView objective={current} kits={kits} productsById={productsById} /> : <p>Aucun objectif.</p>}
        <SampleNote />
      </div>

      <aside className="flex flex-col gap-4">
        <NewObjectiveForm
          kits={kits}
          onCreate={(objective) => {
            dispatch({ type: "addObjective", objective });
            setSelectedId(objective.id);
          }}
        />
        <div className="flex flex-col gap-2.5 border border-line bg-panel px-5 py-4">
          <div className="lbl">Tous les objectifs</div>
          {objectives.map((objective) => {
            const { target, have } = progressOf(objective, kits, productsById);
            const selected = objective.id === current?.id;
            return (
              <button
                key={objective.id}
                type="button"
                onClick={() => setSelectedId(objective.id)}
                className={`flex cursor-pointer flex-col gap-1.5 border bg-transparent p-2.5 text-left ${
                  selected ? "border-gold" : "border-transparent hover:border-line"
                }`}
              >
                <span className="flex w-full justify-between text-[17px] text-parch">
                  <span>{objective.reason}</span>
                  <span className="text-muted2">{formatDate(objective.date)}</span>
                </span>
                <span className="block h-1.5 w-full bg-track">
                  <span className="block h-full bg-gold" style={{ width: `${target ? (have / target) * 100 : 0}%` }} />
                </span>
              </button>
            );
          })}
        </div>
      </aside>
    </div>
  );
}

function ObjectiveView({ objective, kits, productsById }) {
  const { dispatch } = useInventory();
  const { kit, needs, target, have, missing, leatherHave, leatherTarget } = progressOf(objective, kits, productsById);
  const pct = target ? Math.round((have / target) * 100) : 0;
  const kitName = kit ? kit.name.toLowerCase().replace(/^kit /, "kits ") : "kits";

  const missClass = (value, target) => (value === 0 ? "text-ok" : value > target / 4 ? "text-alert-soft" : "text-warn");

  return (
    <>
      <div>
        <div className="eyebrow">Objectif</div>
        <h1 className="sc m-0 mt-1.5 text-[40px] leading-[1.05] text-cream sm:text-[44px]">{objective.reason}</h1>
        <div className="mt-2 text-[19px] text-muted">
          Pour le <span className="text-cream">{formatDate(objective.date)}</span> · {objective.kitCount} {kitName} complets +{" "}
          {objective.basePerTool} de chaque outil à l'unité
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-6 border border-line bg-panel2 px-6 py-4">
        <div className="min-w-[220px] flex-1">
          <div className="mb-2 flex justify-between text-[17px] text-muted">
            <span>Progression globale</span>
            <span className="text-cream">
              {have} / {target} pièces
            </span>
          </div>
          <div className="h-3.5 bg-track">
            <div className="h-full bg-gold" style={{ width: `${pct}%` }} />
          </div>
        </div>
        <div className="text-right">
          <div className="lbl" style={{ color: missing ? "#e8876f" : "#9fc7a4" }}>
            À fabriquer
          </div>
          <div className={`text-[34px] leading-none ${missing ? "text-alert-soft" : "text-ok"}`}>{missing}</div>
        </div>
      </div>

      <div className="border border-line bg-panel">
        <div className="px-4 pt-3.5 pb-0.5 text-[16px] text-muted2">
          Chaque kit complet devient ses pièces :{" "}
          <span className="text-cream">objectif = base à l'unité + {objective.kitCount} × pièces par kit</span>. On compare au stock
          total (réservé + libre).
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[620px] border-collapse">
            <thead>
              <tr>
                <th className="th">Pièce</th>
                <th className="th num">Base</th>
                <th className="th num">Pour {objective.kitCount} kits</th>
                <th className="th num">Objectif</th>
                <th className="th num">En stock</th>
                <th className="th num">Manque</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="td">Étui de cuir (toutes couleurs)</td>
                <td className="td num text-faint">—</td>
                <td className="td num">{leatherTarget}</td>
                <td className="td num text-cream">{leatherTarget}</td>
                <td className="td num">{kit ? leatherTotal(kit) : 0}</td>
                <td className={`td num ${missClass(leatherTarget - leatherHave, leatherTarget)}`}>
                  {leatherTarget - leatherHave || "✓"}
                </td>
              </tr>
              {needs.map((need) => (
                <tr key={need.product.id} className={need.missing > need.target / 4 ? "bg-alert-bg" : undefined}>
                  <td className="td">
                    {need.product.name}
                    {need.product.type === "paquet" && <span className="ml-1.5 text-[15px] text-faint">(paquets)</span>}
                  </td>
                  <td className="td num">{need.base}</td>
                  <td className="td num">{need.forKits}</td>
                  <td className="td num text-cream">{need.target}</td>
                  <td className="td num">{need.stock}</td>
                  <td className={`td num ${missClass(need.missing, need.target)}`}>{need.missing || "✓"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {objective.id !== "obj-1" && (
        <button type="button" className="btn-ghost w-fit" onClick={() => dispatch({ type: "removeObjective", id: objective.id })}>
          Supprimer cet objectif
        </button>
      )}
    </>
  );
}

function NewObjectiveForm({ kits, onCreate }) {
  const [reason, setReason] = useState("");
  const [date, setDate] = useState("");
  const [kitId, setKitId] = useState(kits[0]?.id);
  const [kitCount, setKitCount] = useState("8");
  const [base, setBase] = useState("10");

  function submit(event) {
    event.preventDefault();
    onCreate({
      id: `obj-${Date.now()}`,
      reason: reason.trim() || "Nouvel objectif",
      date,
      kitId,
      kitCount: Math.max(0, parseInt(kitCount, 10) || 0),
      basePerTool: Math.max(0, parseInt(base, 10) || 0),
    });
    setReason("");
  }

  return (
    <form
      aria-label="Nouvel objectif"
      onSubmit={submit}
      className="flex flex-col gap-3.5 border border-gold p-5"
      style={{ background: "linear-gradient(180deg,#1a1109 0%,#0d0805 100%)" }}
    >
      <div className="sc text-[20px] text-cream">Nouvel objectif</div>
      <label className="flex flex-col gap-1.5">
        <span className="lbl">Raison</span>
        <input className="field" placeholder="Ex. salon, commande spéciale…" value={reason} onChange={(e) => setReason(e.target.value)} />
      </label>
      <label className="flex flex-col gap-1.5">
        <span className="lbl">Date</span>
        <input className="field [color-scheme:dark]" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </label>
      <div className="flex flex-col gap-1.5">
        <span className="lbl">Kits complets</span>
        <div className="flex gap-2">
          <select aria-label="Kit" className="field bg-panel2!" value={kitId} onChange={(e) => setKitId(e.target.value)}>
            {kits.map((kit) => (
              <option key={kit.id} value={kit.id}>
                {kit.name}
              </option>
            ))}
          </select>
          <input
            aria-label="Nombre de kits"
            inputMode="numeric"
            className="field w-20! text-center"
            value={kitCount}
            onChange={(e) => setKitCount(e.target.value.replace(/\D/g, ""))}
          />
        </div>
      </div>
      <label className="flex flex-col gap-1.5">
        <span className="lbl">Base par outil à l'unité</span>
        <input inputMode="numeric" className="field" value={base} onChange={(e) => setBase(e.target.value.replace(/\D/g, ""))} />
      </label>
      <button type="submit" className="btn-primary">
        Créer l'objectif
      </button>
    </form>
  );
}
