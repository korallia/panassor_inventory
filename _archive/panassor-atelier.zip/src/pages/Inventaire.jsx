// 1A — Registre (et 1B — vue en cartes).
// Pas de ligne d'étui ici : le kit est une ligne à part, plus grosse, avec
// seulement le nombre de kits prêts et son état.
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";

import { useInventory } from "../store.jsx";
import { ensembleState, kitsReady, productState } from "../lib/inventory.js";
import { PageHeader, SampleNote, StatTile, StatusPill, typeLabel, unitFor } from "../components/ui.jsx";

const SORTS = {
  dispo: { label: "Trier : disponible (bas → haut)", fn: (a, b) => a.free - b.free || a.name.localeCompare(b.name, "fr") },
  nom: { label: "Trier : nom", fn: (a, b) => a.name.localeCompare(b.name, "fr") },
  reserve: { label: "Trier : réservé (haut → bas)", fn: (a, b) => (b.reserved ?? -1) - (a.reserved ?? -1) },
  etat: { label: "Trier : sous le min. d'abord", fn: (a, b) => (a.status === b.status ? a.free - b.free : a.status === "low" ? -1 : 1) },
};

function useRegister() {
  const { collections, products, kits, productsById, reserved } = useInventory();

  return useMemo(() => {
    const kitComponentIds = new Set(kits.flatMap((kit) => kit.components.map((c) => c.productId)));
    const rows = products.map((product) => {
      if (product.type === "ensemble") {
        const state = ensembleState(product, productsById, reserved);
        return {
          product,
          name: product.name,
          free: state.possible,
          reserved: null,
          total: null,
          min: state.objective,
          status: state.possible < state.objective ? "low" : "ok",
        };
      }
      const state = productState(product, reserved);
      return {
        product,
        name: product.name,
        free: state.free,
        reserved: state.reserved,
        total: state.stock,
        min: state.min,
        status: state.status,
        inKit: kitComponentIds.has(product.id),
      };
    });

    const kitRows = kits.map((kit) => {
      const ready = kitsReady(kit, productsById);
      return { kit, ready, status: ready < kit.min ? "low" : "ok" };
    });

    return { collections, rows, kitRows };
  }, [collections, products, kits, productsById, reserved]);
}

export default function Inventaire() {
  const { collections, rows, kitRows } = useRegister();
  const [collectionId, setCollectionId] = useState("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("dispo");
  const [view, setView] = useState("registre");

  const visibleCollections = collections.filter((c) => collectionId === "all" || c.id === collectionId);
  const needle = query.trim().toLowerCase();
  const matches = (name) => !needle || name.toLowerCase().includes(needle);

  const groups = visibleCollections.map((collection) => ({
    collection,
    kits: kitRows.filter((row) => row.kit.collectionId === collection.id && matches(row.kit.name)),
    rows: rows.filter((row) => row.product.collectionId === collection.id && matches(row.name)).sort(SORTS[sort].fn),
  }));

  // Tuiles du haut (sur la sélection de collection, sans la recherche).
  const inScope = rows.filter((row) => visibleCollections.some((c) => c.id === row.product.collectionId));
  const pieces = inScope.filter((row) => row.product.type !== "ensemble");
  const kitsInScope = kitRows.filter((row) => visibleCollections.some((c) => c.id === row.kit.collectionId));
  const totalFree = pieces.reduce((sum, row) => sum + row.free, 0);
  const totalReserved = pieces.reduce((sum, row) => sum + row.reserved, 0);
  const kitsReadyCount = kitsInScope.reduce((sum, row) => sum + row.ready, 0);
  const lowCount = inScope.filter((row) => row.status === "low").length + kitsInScope.filter((row) => row.status === "low").length;

  return (
    <div className="flex flex-col gap-6">
      <PageHeader eyebrow="Registre" title="Inventaire">
        <div className="flex flex-wrap items-center gap-3">
          <input
            aria-label="Rechercher"
            placeholder="Rechercher un produit…"
            className="field w-[260px]!"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
          />
          <select
            aria-label="Trier"
            className="field w-auto! bg-panel2! text-gold-light!"
            value={sort}
            onChange={(event) => setSort(event.target.value)}
          >
            {Object.entries(SORTS).map(([key, value]) => (
              <option key={key} value={key}>
                {value.label}
              </option>
            ))}
          </select>
          <div className="flex" role="group" aria-label="Affichage">
            {[
              ["registre", "Registre"],
              ["cartes", "Cartes"],
            ].map(([key, label]) => (
              <button
                key={key}
                type="button"
                aria-pressed={view === key}
                onClick={() => setView(key)}
                className={`sc h-11 cursor-pointer border px-4 text-[14px] tracking-[.12em] ${
                  view === key ? "border-gold bg-gold/12 text-cream" : "border-line bg-transparent text-muted2"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </PageHeader>

      <div role="tablist" aria-label="Collection" className="flex overflow-x-auto border-b border-line">
        {[{ id: "all", name: "Toutes" }, ...collections].map((collection) => {
          const selected = collectionId === collection.id;
          return (
            <button
              key={collection.id}
              role="tab"
              aria-selected={selected}
              onClick={() => setCollectionId(collection.id)}
              className={`sc h-12 shrink-0 cursor-pointer border-0 border-b-2 bg-transparent px-5 text-[16px] tracking-[.12em] ${
                selected ? "border-gold text-cream" : "border-transparent text-muted2 hover:text-cream"
              }`}
            >
              {collection.name}
            </button>
          );
        })}
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatTile label="Disponibles" value={totalFree} note="pièces et paquets libres à vendre à l'unité" />
        <StatTile label="Réservées pour kits" value={totalReserved} note={`bloquées pour ${kitsReadyCount} kits prêts`} />
        <StatTile label="Sous le minimum" value={lowCount} note="produits à refaire bientôt" alert={lowCount > 0} />
      </div>

      {view === "registre" ? <RegisterTable groups={groups} /> : <CardsView groups={groups} />}
      <SampleNote />
    </div>
  );
}

function RegisterTable({ groups }) {
  return (
    <div className="overflow-x-auto border border-line bg-panel">
      <table className="w-full min-w-[760px] border-collapse">
        <thead>
          <tr>
            <th className="th">Produit</th>
            <th className="th">Type</th>
            <th className="th num">Disponible</th>
            <th className="th num">Réservé</th>
            <th className="th num">Total</th>
            <th className="th num">Min.</th>
            <th className="th">État</th>
          </tr>
        </thead>
        <tbody>
          {groups.map(({ collection, kits, rows }) =>
            kits.length === 0 && rows.length === 0 ? null : (
              <GroupRows key={collection.id} collection={collection} kits={kits} rows={rows} />
            )
          )}
        </tbody>
      </table>
    </div>
  );
}

function GroupRows({ collection, kits, rows }) {
  return (
    <>
      <tr>
        <td colSpan={7} className="sc bg-panel2 px-4 pb-2 pt-3.5 text-[15px] tracking-[.22em] text-gold">
          {collection.name}
        </td>
      </tr>
      {kits.map(({ kit, ready, status }) => (
        <tr key={kit.id} style={{ background: "linear-gradient(90deg,rgba(200,155,60,.16),rgba(200,155,60,.03))" }}>
          <td className="td py-4! text-[24px]! font-semibold">
            <Link to={`/kits/${kit.id}`} className="text-cream! no-underline">
              {kit.name}
            </Link>
          </td>
          <td className="td sc text-[14px]! tracking-[.14em] text-gold">Kit complet</td>
          <td className={`td num text-[30px]! font-semibold ${status === "low" ? "text-alert-soft" : "text-cream"}`}>
            {ready}
          </td>
          <td className="td" colSpan={2} />
          <td className="td num text-muted2">{kit.min}</td>
          <td className="td">
            <StatusPill status={status} />
          </td>
        </tr>
      ))}
      {rows.map((row) => {
        const unit = unitFor(row.product, 2);
        return (
          <tr key={row.product.id} className="hover:bg-gold/5">
            <td className="td">
              <Link to={`/produits/${row.product.id}`} className="text-parch!">
                {row.name}
              </Link>
            </td>
            <td className="td text-muted2">{typeLabel(row.product, row.inKit)}</td>
            <td className={`td num ${row.status === "low" ? "text-alert-soft" : ""}`}>
              {row.free}
              {unit && <span className="ml-1.5 text-[14px] text-faint">{unit}</span>}
            </td>
            <td className="td num text-muted2">{row.reserved ?? "—"}</td>
            <td className="td num">{row.total ?? <span className="text-muted2">—</span>}</td>
            <td className="td num text-muted2">{row.min}</td>
            <td className="td">
              <StatusPill status={row.status} />
            </td>
          </tr>
        );
      })}
    </>
  );
}

function CardsView({ groups }) {
  return (
    <div className="flex flex-col gap-7">
      {groups.map(({ collection, kits, rows }) =>
        kits.length === 0 && rows.length === 0 ? null : (
          <section key={collection.id} className="flex flex-col gap-3">
            <h2 className="sc m-0 text-[15px] tracking-[.22em] text-gold">{collection.name}</h2>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {kits.map(({ kit, ready, status }) => (
                <Link
                  key={kit.id}
                  to={`/kits/${kit.id}`}
                  className="flex flex-col gap-2 border border-gold p-5 no-underline"
                  style={{ background: "linear-gradient(180deg,rgba(200,155,60,.16),rgba(200,155,60,.03))" }}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[22px] font-semibold text-cream">{kit.name}</span>
                    <StatusPill status={status} />
                  </div>
                  <div className={`text-[44px] leading-none font-semibold ${status === "low" ? "text-alert-soft" : "text-cream"}`}>
                    {ready}
                  </div>
                  <div className="text-[15px] text-muted2">kits prêts · minimum {kit.min}</div>
                </Link>
              ))}
              {rows.map((row) => {
                const low = row.status === "low";
                const barMax = Math.max(row.min, row.free, 1);
                return (
                  <Link
                    key={row.product.id}
                    to={`/produits/${row.product.id}`}
                    className={`flex flex-col gap-2 border p-5 no-underline ${low ? "border-alert-line bg-alert-bg" : "border-line bg-panel2"}`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-[20px] text-cream">{row.name}</span>
                      <StatusPill status={row.status} />
                    </div>
                    <div className={`text-[36px] leading-none ${low ? "text-alert-soft" : "text-cream"}`}>
                      {row.free}
                      <span className="ml-2 text-[15px] text-muted2">
                        {unitFor(row.product, row.free) ?? "libres"}
                        {row.reserved ? ` · ${row.reserved} réservés` : ""}
                      </span>
                    </div>
                    <div className="h-1.5 bg-track">
                      <div
                        className="h-full"
                        style={{ width: `${Math.min(100, (row.free / barMax) * 100)}%`, background: low ? "#e8876f" : "#c89b3c" }}
                      />
                    </div>
                    <div className="text-[14px] text-faint">
                      {row.product.type === "ensemble" ? "objectif" : "minimum"} {row.min}
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        )
      )}
    </div>
  );
}
