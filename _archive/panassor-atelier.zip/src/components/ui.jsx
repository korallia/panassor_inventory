// Petites briques visuelles partagées par toutes les pages.
import { Link } from "react-router-dom";

// ---------- Cases (1 case = 1 unité) ----------
// Couleur seulement, pas d'icône :
//   reserved  vert       réservé pour les kits
//   free      or plein   libre / pour les ensembles
//   solo      or pâle    vendable seul (3e couche des ensembles)
//   missing   pointillé  manque
//   orphan    gris plein pièce orpheline (hors stock)
const SLOT_STYLES = {
  reserved: { background: "#3f6b48", border: "1px solid #9fc7a4" },
  free: { background: "#e0b04f", border: "1px solid #fff1d2" },
  solo: { background: "rgba(224,176,79,.22)", border: "1px solid #8a6a2c" },
  missing: { background: "rgba(232,135,111,.10)", border: "2px dashed #e8876f" },
  orphan: { background: "#4a4238", border: "1px solid #8f8577" },
};

const SLOT_SIZES = {
  lg: { width: 52, height: 64 },
  sm: { width: 30, height: 40 },
  xs: { width: 16, height: 22 },
};

export function Slot({ kind, size = "lg", title }) {
  return (
    <span
      title={title}
      className="inline-block shrink-0 box-border"
      style={{ ...SLOT_SIZES[size], ...SLOT_STYLES[kind] }}
    />
  );
}

/** Une série de cases identiques. */
export function Slots({ kind, count, size = "lg", title }) {
  if (count <= 0) return null;
  return Array.from({ length: count }, (_, index) => <Slot key={`${kind}-${index}`} kind={kind} size={size} title={title} />);
}

/** Petite case de légende + texte. */
export function Legend({ kind, children, layer }) {
  return (
    <span className="flex items-center gap-2">
      {layer && <LayerBadge layer={layer} />}
      <Slot kind={kind} size="xs" />
      {children}
    </span>
  );
}

const LAYER_COLORS = {
  1: { borderColor: "#9fc7a4", color: "#9fc7a4" },
  2: { borderColor: "#e7c97b", color: "#e7c97b" },
  3: { borderColor: "#8a6a2c", color: "#c89b3c" },
};

export function LayerBadge({ layer }) {
  return (
    <span
      className="sc flex h-[22px] w-[22px] items-center justify-center border text-[13px]"
      style={LAYER_COLORS[layer]}
    >
      {layer}
    </span>
  );
}

/** Groupe de cases coiffé d'une étiquette et d'une accolade. */
export function SlotGroup({ label, bracketColor = "#c89b3c", labelColor = "#e7c97b", children }) {
  return (
    <div className="flex w-fit max-w-full min-w-0 flex-col gap-2.5">
      <span className="sc text-[15px] tracking-[.16em]" style={{ color: labelColor }}>
        {label}
      </span>
      <div className="h-2.5 border border-b-0" style={{ borderColor: bracketColor }} />
      <div className="flex flex-wrap gap-2">{children}</div>
    </div>
  );
}

// ---------- États ----------
export function StatusPill({ status }) {
  const low = status === "low";
  return (
    <span
      className="sc inline-block whitespace-nowrap border px-2.5 py-0.5 text-[13px] tracking-[.08em]"
      style={low ? { color: "#e8876f", borderColor: "#9b4a36" } : { color: "#9fc7a4", borderColor: "#3f6b48" }}
    >
      {low ? "Sous le min." : "OK"}
    </span>
  );
}

// ---------- Tuiles de chiffres ----------
export function StatTile({ label, value, unit, note, alert = false }) {
  return (
    <div className={`border px-5 py-4 ${alert ? "border-alert-line bg-alert-bg" : "border-line bg-panel2"}`}>
      <div className="lbl" style={alert ? { color: "#d7b5a8" } : undefined}>
        {label}
      </div>
      <div className={`mt-2 text-[40px] leading-[1.1] ${alert ? "text-alert-soft" : "text-cream"}`}>
        {value}
        {unit && <span className={`ml-2 text-[18px] ${alert ? "text-alert-muted" : "text-muted2"}`}>{unit}</span>}
      </div>
      {note && <div className={`text-[15px] ${alert ? "text-alert-muted" : "text-muted2"}`}>{note}</div>}
    </div>
  );
}

/** Encadré d'état en haut à droite des fiches (« Sous le minimum −8 »). */
export function StatusBanner({ low, lowLabel = "Sous le minimum", missing, missingLabel }) {
  if (!low) {
    return (
      <div className="flex items-center gap-4 border border-ok-line bg-[#0e1a10] px-5 py-3.5">
        <div className="sc text-[16px] tracking-[.14em] text-ok">OK</div>
      </div>
    );
  }
  return (
    <div className="flex items-center gap-4 border border-alert-line bg-alert-bg px-5 py-3.5">
      <div className="sc text-[16px] tracking-[.14em] text-alert">{lowLabel}</div>
      <div className="h-[34px] w-px bg-alert-line" />
      <div className="flex items-baseline gap-2">
        <span className="text-[40px] leading-none text-alert-soft">−{missing}</span>
        <span className="lbl" style={{ color: "#d7b5a8" }}>
          {missingLabel}
        </span>
      </div>
    </div>
  );
}

// ---------- En-têtes ----------
export function PageHeader({ eyebrow, title, back, children }) {
  return (
    <div className="flex flex-col gap-4">
      {back && (
        <Link to={back.to} className="w-fit text-[17px] no-underline">
          ← {back.label}
        </Link>
      )}
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div>
          {eyebrow && <div className="eyebrow">{eyebrow}</div>}
          <h1 className="sc m-0 mt-1.5 text-[40px] leading-none text-cream sm:text-[52px]">{title}</h1>
        </div>
        {children}
      </div>
    </div>
  );
}

// ---------- Saisie ----------
/** Champ numérique avec boutons − / +, pour tester les calculs. */
export function Stepper({ value, onChange, label, small = false }) {
  const height = small ? "h-9" : "h-11";
  return (
    <div className="inline-flex items-stretch" role="group" aria-label={label}>
      <button
        type="button"
        aria-label={`${label} : retirer 1`}
        className={`${height} w-9 cursor-pointer border border-line bg-panel2 text-[20px] text-gold-light hover:text-cream`}
        onClick={() => onChange(value - 1)}
      >
        −
      </button>
      <input
        aria-label={label}
        inputMode="numeric"
        className={`${height} w-16 border-y border-line bg-ink text-center text-[18px] text-parch tabular-nums`}
        value={value}
        onChange={(event) => onChange(event.target.value.replace(/\D/g, ""))}
      />
      <button
        type="button"
        aria-label={`${label} : ajouter 1`}
        className={`${height} w-9 cursor-pointer border border-line bg-panel2 text-[20px] text-gold-light hover:text-cream`}
        onClick={() => onChange(value + 1)}
      >
        +
      </button>
    </div>
  );
}

export function SampleNote() {
  return <div className="text-[14px] text-faint">Quantités d'exemple : rien n'est relié à la vraie base ni à Square.</div>;
}

/** Libellé lisible d'un type de produit. */
export function typeLabel(product, inKit) {
  switch (product.type) {
    case "paquet":
      return "Paquet de 2";
    case "ensemble":
      return "Ensemble";
    case "outil":
      return "Outil au choix";
    default:
      return inKit ? "Pièce du kit" : "Pièce";
  }
}

/** « paquets » partout où un paquet est compté. */
export function unitFor(product, count) {
  if (product?.type === "paquet") return count === 1 ? "paquet" : "paquets";
  if (product?.type === "ensemble") return count === 1 ? "ensemble" : "ensembles";
  return null;
}
